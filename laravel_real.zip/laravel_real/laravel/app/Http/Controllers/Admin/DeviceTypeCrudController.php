<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\DeviceTypeRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;

use Illuminate\Validation\Rule;

/**
 * Class DeviceTypeCrudController
 * @package App\Http\Controllers\Admin
 * @property-read \Backpack\CRUD\app\Library\CrudPanel\CrudPanel $crud
 */
class DeviceTypeCrudController extends CrudController
{
    use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;

    /**
     * Configure the CrudPanel object. Apply settings to all operations.
     * 
     * @return void
     */
    public function setup()
    {
        CRUD::setModel(\App\Models\DeviceType::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/device-type');
        CRUD::setEntityNameStrings(__('messages.device_type'), __('messages.device_types'));
    }

    /**
     * Define what happens when the List operation is loaded.
     * 
     * @see  https://backpackforlaravel.com/docs/crud-operation-list-entries
     * @return void
     */
    protected function setupListOperation()
    {
        CRUD::setFromDb(); // set columns from db columns.
        CRUD::column('created_at')->type('datetime');
    }

    /**
     * Define what happens when the Create operation is loaded.
     * 
     * @see https://backpackforlaravel.com/docs/crud-operation-create
     * @return void
     */
    protected function setupCreateOperation()
    {
        CRUD::setValidation(DeviceTypeRequest::class);
        CRUD::setFromDb(); // set fields from db columns.

        // validation rules
        $rules = [
            'device_type_name' => 'required|unique:devices_types,device_type_name|min:1',
            'device_model_number' => 'required|unique:devices_types,device_model_number|min:1',
        ];
        $messages = [
            'device_type_name.required' => __('messages.device_type_name_required'),
            'device_type_name.min' => __('messages.min_length', ['min' => 1]),
            'device_model_number.required' => __('messages.device_model_number_required'),
            'device_model_number.unique' => __('messages.device_model_number_exists'),
            'device_model_number.min' => __('messages.min_length', ['min' => 1]),
        ];
        [];
        $this->crud->setValidation($rules, $messages);
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();

        // validation rules
        $rules = [
            'device_type_name' => [
                'required',
                'min:1',
                Rule::unique('devices_types', 'device_type_name')->ignore($this->crud->getCurrentEntryId()),
            ],
            'device_model_number' => [
                'required',
                'min:1',
                Rule::unique('devices_types', 'device_model_number')->ignore($this->crud->getCurrentEntryId()),
            ]
        ];

        $this->crud->setValidation($rules);
    }
}
