<?php

return [
    // Menü öğeleri
    'dashboard' => 'Kontrol Paneli',
    'devices' => 'Cihazlar',
    'appliances' => 'Ürünler',
    'settings' => 'Ayarlar',
    'language' => 'Dil',
    
    // Genel işlemler
    'add' => 'Ekle',
    'edit' => 'Düzenle',
    'delete' => 'Sil',
    'save' => 'Kaydet',
    'cancel' => 'İptal',
    'search' => 'Ara',
    'filter' => 'Filtrele',
    
    // Cihaz yönetimi
    'device_name' => 'Cihaz Adı',
    'device_type' => 'Cihaz Tipi',
    'device_status' => 'Durum',
    'device_ip' => 'IP Adresi',
    'device_mac' => 'MAC Adresi',
    'scan_devices' => 'Cihazları Tara',
    'add_device' => 'Cihaz Ekle',
    'edit_device' => 'Cihazı Düzenle',
    'delete_device' => 'Cihazı Sil',
    
    // Ürün yönetimi
    'appliance_name' => 'Ürün Adı',
    'appliance_type' => 'Ürün Tipi',
    'add_appliance' => 'Ürün Ekle',
    'edit_appliance' => 'Ürünü Düzenle',
    'delete_appliance' => 'Ürünü Sil',
    
    // Başarı mesajları
    'device_added' => 'Cihaz başarıyla eklendi',
    'device_updated' => 'Cihaz başarıyla güncellendi',
    'device_deleted' => 'Cihaz başarıyla silindi',
    'appliance_added' => 'Ürün başarıyla eklendi',
    'appliance_updated' => 'Ürün başarıyla güncellendi',
    'appliance_deleted' => 'Ürün başarıyla silindi',
    'settings_saved' => 'Ayarlar başarıyla kaydedildi',
    
    // Hata mesajları
    'error_occurred' => 'Bir hata oluştu',
    'device_not_found' => 'Cihaz bulunamadı',
    'appliance_not_found' => 'Ürün bulunamadı',
    'connection_failed' => 'Bağlantı başarısız',
    'invalid_data' => 'Geçersiz veri',
    'permission_denied' => 'İzin reddedildi',
    
    // Doğrulama mesajları
    'field_required' => 'Bu alan gereklidir',
    'invalid_ip' => 'Geçersiz IP adresi',
    'invalid_mac' => 'Geçersiz MAC adresi',
    'name_exists' => 'Bu isim zaten mevcut',
];
