<?php

return [
    // Menu items
    'dashboard' => 'Dashboard',
    'devices' => 'Devices',
    'appliances' => 'Appliances',
    'settings' => 'Settings',
    'language' => 'Language',
    
    // Common actions
    'add' => 'Add',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'save' => 'Save',
    'cancel' => 'Cancel',
    'search' => 'Search',
    'filter' => 'Filter',
    
    // Device management
    'device_name' => 'Device Name',
    'device_type' => 'Device Type',
    'device_status' => 'Status',
    'device_ip' => 'IP Address',
    'device_mac' => 'MAC Address',
    'scan_devices' => 'Scan Devices',
    'add_device' => 'Add Device',
    'edit_device' => 'Edit Device',
    'delete_device' => 'Delete Device',
    
    // Appliance management
    'appliance_name' => 'Appliance Name',
    'appliance_type' => 'Appliance Type',
    'add_appliance' => 'Add Appliance',
    'edit_appliance' => 'Edit Appliance',
    'delete_appliance' => 'Delete Appliance',
    
    // Success messages
    'device_added' => 'Device added successfully',
    'device_updated' => 'Device updated successfully',
    'device_deleted' => 'Device deleted successfully',
    'appliance_added' => 'Appliance added successfully',
    'appliance_updated' => 'Appliance updated successfully',
    'appliance_deleted' => 'Appliance deleted successfully',
    'settings_saved' => 'Settings saved successfully',
    
    // Error messages
    'error_occurred' => 'An error occurred',
    'device_not_found' => 'Device not found',
    'appliance_not_found' => 'Appliance not found',
    'connection_failed' => 'Connection failed',
    'invalid_data' => 'Invalid data',
    'permission_denied' => 'Permission denied',
    
    // Validation messages
    'field_required' => 'This field is required',
    'invalid_ip' => 'Invalid IP address',
    'invalid_mac' => 'Invalid MAC address',
    'name_exists' => 'This name already exists',
];
