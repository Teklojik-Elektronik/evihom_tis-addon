<div class="form-check form-switch">
<input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked{{$id}}" {{$checked}} onclick="updateState({{$id}})">
<label class="form-check-label" for="flexSwitchCheckChecked{{$id}}">{{$label}}</label>
</div>