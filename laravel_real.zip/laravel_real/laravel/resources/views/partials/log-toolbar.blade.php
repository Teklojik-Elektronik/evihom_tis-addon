<div class="log-toolbar">
    <div class="log-filter">
        <button class="filter-button active" data-filter="all">All</button>
        <button class="filter-button error" data-filter="error">Errors</button>
        <button class="filter-button warning" data-filter="warning">Warnings</button>
        <button class="filter-button info" data-filter="info">Info</button>
    </div>
    <div class="log-actions">
        <span class="log-title" id="lineCount">Showing all logs</span>
    </div>
</div>
